<?php
    /**
     * @file module/referer/lang/ko.lang.php
     * @author haneul <haneul0318@gmail.com>
     * @brief English language pack
     */

    $lang->referer = "Referer";
    $lang->ranking = "Ranking";
?>
