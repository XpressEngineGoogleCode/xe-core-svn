<?php
    /**
     * @file   /modules/editor/components/emoticon/lang/en.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  editor module >  language pack of table_maker component
     **/

     $lang->table_attribute = "Cambiar el cuadro Attibution";
     $lang->cell_attribute = "Cambio de celda Atribucion";

     $lang->table_width = "Ancho";
     $lang->table_cols_count = "Numero de columnas";
     $lang->table_rows_count = "Numero de filas";
     $lang->table_cellspacing = "Cellspacing";
     $lang->table_cellpadding = "Cellpadding";
     $lang->table_border = "Thicknes Frontera";
     $lang->table_inner_border = "Inner Grosor de linea";

     $lang->cell_width = "Ancho";
     $lang->cell_height = "Altura";

     $lang->table_border_color = "Color del borde";
     $lang->table_bg_color = "Color de fondo";
?>
