<?php
    /**
     * @file   /modules/editor/components/multimedia_link/lang/en.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  editor module > language pack of multimedia_link component
     **/

     $lang->multimedia_url = "Sendero Multimedia";
     $lang->multimedia_caption = "Descripcion de Entrada";
     $lang->multimedia_width = "Ancho";
     $lang->multimedia_height = "Altura";
     $lang->multimedia_auto_start = "Auto Start";
	 
?>
