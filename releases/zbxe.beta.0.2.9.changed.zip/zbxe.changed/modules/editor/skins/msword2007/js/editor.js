// Editor Option Button 
function eOptionOver2(obj) {
    obj.style.marginTop='-22px';	
    obj.style.zIndex='99';	
}

function eOptionClick2(obj) {
    obj.style.marginTop='-44px';	
    obj.style.zIndex='99';
}
