<?php
    /**
     * @file   es.lang.php
     * @author haneul (haneul0318@gmail.com)
     * @brief  Paquete de idioma por defecto de lifepod módulo
     **/

    $lang->lifepod = "Lifepod";

    $lang->calendar_address = "Calendario de la Dirección XML";
    $lang->cmd_lifepod_list = 'Lista Lifepod';
    $lang->cmd_view_info = 'Lifepod Información.';

    $lang->about_lifepod = "Lifepod calendario es un servicio proporcionado por Openmaru Studio.<br />Lifepod Zeroboard XE módulo desplays Lifepod específicas de calendarios como documentos internos.";
?>
