<?php
    $lang->alert_new_message_arrived = '새로운 메세지가 도착하였습니다. 확인하시겠습니까?';
?>
