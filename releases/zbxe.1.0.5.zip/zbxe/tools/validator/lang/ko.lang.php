<?php
    $lang->validator = '설치파일 검증';

    $lang->msg_cannot_get_source_files = '원본 파일을 다운로드 하지 못했습니다';
    $lang->msg_cannot_get_target_files = '설치된 대상 파일의 목록을 구하지 못했습니다';

    $lang->files_count = '파일 수';
    $lang->source_files = '원본 파일';
    $lang->target_files = '대상 파일';

    $lang->leaveout_files = '누락된 파일';
    $lang->modified_files = '수정된 파일'; 
    $lang->additional_files = '추가된 파일';
?>
