<?php
    $lang->cache_cleaner = '캐시파일 재생성';
?>
