<?php
    $lang->commentnotify = 'Comment Notifier';
    $lang->msg_checked_comment_is_deleted = '%d comment(s) has(have) been deleted';
    $lang->cmd_delete_checked_comment = 'Delete Selected Items';
?>
