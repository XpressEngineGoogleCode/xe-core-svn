<?php
    $lang->commentnotify = '댓글알리미';
    $lang->msg_checked_comment_is_deleted = '%d개의 알림글이 삭제되었습니다';
    $lang->cmd_delete_checked_comment = '선택삭제';
?>
