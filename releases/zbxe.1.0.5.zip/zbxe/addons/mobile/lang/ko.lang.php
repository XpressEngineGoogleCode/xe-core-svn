<?php
    /**
     * @file   addons/mobile/lang/ko.lang.php
     * @author zero (zero@nzeo.com)
     * @brief  한국어 언어팩 (기본적인 내용만 수록)
     **/

    $lang->cmd_go_upper = '상위';
    $lang->cmd_go_home = '홈으로';
?>
