<?php
    /**
     * @class  adminAdminModel
     * @author zero (zero@nzeo.com)
     * @brief  admin 모듈의 admin model class
     **/

    class adminAdminModel extends admin {

        /**
         * @brief 초기화
         **/
        function init() {
        }

    }
?>
