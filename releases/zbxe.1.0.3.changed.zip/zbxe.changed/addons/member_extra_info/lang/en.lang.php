<?php
    $lang->alert_new_message_arrived = 'You have a new message. Do you want to check now?';
?>
