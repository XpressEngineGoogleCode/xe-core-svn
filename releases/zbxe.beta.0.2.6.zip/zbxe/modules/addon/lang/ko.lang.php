<?php
    /**
     * @file   ko.lang.php
     * @author zero (zero@nzeo.com)
     * @brief  한국어 언어팩 
     **/

    $lang->addon = "애드온";

    $lang->addon_info = '애드온정보';
    $lang->addon_maker = '애드온 제작자';
    $lang->addon_history = '변경 사항 ';

    $lang->about_addon = '애드온은 html결과물을 출력하기 보다 동작을 제어하는 역할을 합니다.<br />원하시는 애드온을 on/ off하시는 것만으로 사이트 운영에 유용한 기능을 연동할 수 있습니다.';
?>
