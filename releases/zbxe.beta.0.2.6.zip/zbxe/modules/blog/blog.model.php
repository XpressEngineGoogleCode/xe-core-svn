<?php
    /**
     * @class  blogModel
     * @author zero (zero@nzeo.com)
     * @version 0.1
     * @brief  blog 모듈의 Model class
     **/

    class blogModel extends blog {

        /**
         * @brief 초기화
         **/
        function init() {
        }
    }
?>
