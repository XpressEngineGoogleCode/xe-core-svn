<?php
    if(!defined("__ZBXE__")) exit();

    /**
     * @brief 포인트 애드온은 포인트 모듈의 trigger 기능으로 인하여 더 이상 사용하지 않음
     **/
    return;
?>
