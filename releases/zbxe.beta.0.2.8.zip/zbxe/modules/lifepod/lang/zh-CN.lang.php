<?php
    /**
     * @file   ko.lang.php
     * @author haneul (haneul0318@gmail.com)
     * @brief  模块lifepod的语言包
     **/

    $lang->lifepod = "Lifepod";

    $lang->calendar_address = "日历 xml地址";
    $lang->cmd_lifepod_list = 'Lifepod目录';
    $lang->cmd_view_info = 'Lifepod信息';

    $lang->about_lifepod = "Lifepod是openmaru提供的日历服务。<br />Lifepod zerboardXE模块是Lifepod的特定日历显示为内部文件形式的模块。";
?>
