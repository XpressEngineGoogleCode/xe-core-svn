<?php
    /**
     * @archivo   es.lang.php
     * @autor zero (zero@nzeo.com)
     * @sumario Paquete del idioma español 
     **/

    $lang->addon = "Addon";

    $lang->addon_info = 'Información de Addon';
    $lang->addon_maker = 'Autor de Addon';
    $lang->addon_history = 'Historia de Addon ';

    $lang->about_addon_mid = "애드온이 사용될 대상을 지정할 수 있습니다.<br />(모두 해제시 모든 대상에서 사용 가능합니다)";
    $lang->about_addon = 'Addon is para controlar las acciones y no para mostrar el resultado en HTML.<br /> Sólo con activar o desactivar el addon que desee, podrá obtener funciones útiles para la administración de tu sitio web.';
?>
