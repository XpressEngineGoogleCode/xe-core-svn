<?php
    /**
     * @file   modules/message/lang/en.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  English language pack (basic)
     **/

    $lang->message = 'Display Errors';
    $lang->about_skin = "You may select skins of error messages";
?>
