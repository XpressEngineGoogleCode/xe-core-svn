<?php
    /**
     * @file   modules/session/lang/zh-CN.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  中文语言包
     **/

    $lang->session = '会话';
    $lang->about_session = "管理会话的模块。\n有时间清理无用会话，可提高网站效率。";

    $lang->cmd_clear_session = '清理会话';
    $lang->session_cleared = '无用会话已清理完毕。';
?>
