<?php
    $lang->alert_new_message_arrived = '新しいメッセージが届きました。確認しますか。';
?>
