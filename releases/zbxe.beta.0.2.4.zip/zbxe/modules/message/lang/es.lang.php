<?php
    /**
     * @archivo   modules/message/lang/es.lang.php
     * @autor zero <zero@nzeo.com>
     * @sumario Paquete del idioma español (básico)
 **/

    $lang->message = 'Mostrar el error';
    $lang->about_skin = "Usted puede seleccionar los temas de los mensajes del error.";
?>
