<?php
    /**
     * @file   /modules/editor/components/code_highlighter/lang/ko.lang.php
     * @author BNU <bnufactory@gamil.com>
     * @brief  위지윅에디터(editor) 모듈 >  코드하이라이터 (code_highlighter) 컴포넌트의 언어팩
     **/
    $lang->code_type = '언어 종류';

    $lang->used_collapse = '접기 기능 사용';
    $lang->hidden_linenumber = '줄 번호 감추기';
    $lang->hidden_controls = '도구바 감추기';
?>