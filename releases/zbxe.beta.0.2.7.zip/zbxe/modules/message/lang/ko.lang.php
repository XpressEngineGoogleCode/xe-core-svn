<?php
    /**
     * @file   modules/message/lang/ko.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  한국어 언어팩 (기본적인 내용만 수록)
     **/

    $lang->message = '오류 표시';
    $lang->about_skin = "메세지 출력시 스킨을 지정하실 수 있습니다.";
?>
