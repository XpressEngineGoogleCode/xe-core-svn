<?php
    /**
     * @file   /modules/editor/components/code_highlighter/lang/jp.lang.php
     * @author BNU <bnufactory@gamil.com> 翻訳：ミニミ
     * @brief  ウイジウイグエディター(editor) モジュール >  コードハイライター (code_highlighter) コンポーネントの言語パッケージ
     **/
    $lang->code_type = '言語種類';

    $lang->used_collapse = '折りたたみ機能を使う';
    $lang->hidden_linenumber = '行番号を隠す';
    $lang->hidden_controls = 'ツールバーを隠す';
?>