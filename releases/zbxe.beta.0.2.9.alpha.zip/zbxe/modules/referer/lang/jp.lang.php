<?php
    /**
     * @file module/referer/lang/ko.lang.php
     * @author haneul <haneul0318@gmail.com>
     * @brief 日本語言語パッケージ　翻訳：RisaPapa
     */

    $lang->referer = "レファラー";
    $lang->ranking = "順位";
?>
