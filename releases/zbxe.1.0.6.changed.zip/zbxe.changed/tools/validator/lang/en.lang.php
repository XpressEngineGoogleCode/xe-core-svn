<?php
    $lang->validator = 'Validator';

    $lang->msg_cannot_get_source_files = 'Could not download original files';
    $lang->msg_cannot_get_target_files = 'Could not get installed target list';

    $lang->files_count = 'Number of Files';
    $lang->source_files = 'Original File';
    $lang->target_files = 'Target File';

    $lang->leaveout_files = 'Omitted File';
    $lang->modified_files = 'Modified File'; 
    $lang->additional_files = 'Added File';
?>
