<?php
    $lang->blank_cleaner = 'Remove Empty Directories';
?>
