<?php
    /**
     * @file   modules/message/lang/fr.lang.php
     * @author zero <zero@nzeo.com> traduit par Pierre Duvent <PierreDuvent@gamil.com>
     * @brief  Paque du langage en français pour le module de Message
     **/

    $lang->message = 'Montrer Erreurs';
    $lang->about_skin = "Vous pouvez choisir un habillage pour le message des erreurs";
?>
