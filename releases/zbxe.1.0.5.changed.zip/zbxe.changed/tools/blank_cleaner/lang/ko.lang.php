<?php
    $lang->blank_cleaner = '빈디렉토리 삭제';
?>
