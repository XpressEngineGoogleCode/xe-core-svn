<?php
    /**
     * @file   /modules/editor/components/multimedia_link/lang/jp.lang.php
     * @author zero <zero@nzeo.com> 翻訳：RisaPapa
     * @brief  ウィジウィグエディター（editor）モジュール > マルチメディアリンク（(multimedia_link）コンポネント言語パッケージ
     **/

    $lang->multimedia_url = "マルチメディアのパス";
    $lang->multimedia_caption = "説明入力";
    $lang->multimedia_width = "横幅サイズ";
    $lang->multimedia_height = "縦幅サイズ";
    $lang->multimedia_auto_start = "自動再生";
?>
