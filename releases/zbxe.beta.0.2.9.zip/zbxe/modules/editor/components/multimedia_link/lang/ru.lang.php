<?php
    /**
     * @file   /modules/editor/components/multimedia_link/lang/ru.lang.php
     * @author zero <zero@nzeo.com>> | translation by Maslennikov Evgeny aka X-[Vr]bL1s5 | e-mail: x-bliss[a]tut.by; ICQ: 225035467;
     * @brief  editor module > language pack of multimedia_link component
     **/

    $lang->multimedia_url = "Путь мультимедиа";
    $lang->multimedia_caption = "Введите описание";
    $lang->multimedia_width = "Ширина";
    $lang->multimedia_height = "Высота";
    $lang->multimedia_auto_start = "Автозапуск";
?>
