<?php
    /**
     * @file   /modules/editor/components/multimedia_link/lang/en.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  editor module > language pack of multimedia_link component
     **/

    $lang->multimedia_url = "Multimedia Path";
    $lang->multimedia_caption = "Input Description";
    $lang->multimedia_width = "Width";
    $lang->multimedia_height = "Height";
    $lang->multimedia_auto_start = "Auto Start";
?>
