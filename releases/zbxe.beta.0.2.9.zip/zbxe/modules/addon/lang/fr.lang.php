<?php
    /**
     * @file   fr.lang.php
     * @author zero (zero@nzeo.com)
     * @brief  Paquet Francais de Langue
     **/

    $lang->addon = "Additions";

    $lang->addon_info = 'Un resume de ce additions';
    $lang->addon_maker = 'Le createur de ce additions';
    $lang->addon_history = 'L\'histoire de ce additions';

    $lang->about_addon = 'Les operations de service de additions plutot que le HTML reel results.<br/>Simply basculant n\'importe quel additions te permet en marche et en arret d\'employer les dispositifs utiles.';
?>
