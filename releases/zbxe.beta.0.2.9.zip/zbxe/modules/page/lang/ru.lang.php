<?php
  /**
     * @file   ru.lang.php
     * @author zero <zero@nzeo.com> | translation by Maslennikov Evgeny aka X-[Vr]bL1s5 | e-mail: x-bliss[a]tut.by; ICQ: 225035467;
     * @brief  Russian basic language pack for Zeroboard XE
     **/

    $lang->page = "Страница";
    $lang->about_page = "Это модуль блога, который создает полную страницу.\nИспользуя последние и другие виджеты, Вы можете создавать динамические страницы. Посредством компонента редактора, Вы можете также создать различные вариации страницы.\nURL модуля следует тем же правилам, что и другие модули: mid=имя_модуля.\n Если он выбран как модуль по умолчанию, то он будет главной страницей сайта.";
    $lang->cmd_page_modify = "Изменить";
?>
