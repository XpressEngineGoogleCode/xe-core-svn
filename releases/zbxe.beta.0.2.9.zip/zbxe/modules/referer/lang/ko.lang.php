<?php
    /**
     * @file module/referer/lang/ko.lang.php
     * @author haneul <haneul0318@gmail.com>
     * @brief Korean language pack
     */

    $lang->referer = "레퍼러";
    $lang->ranking = "순위";
?>
