<?php
    /**
     * @file module/referer/lang/ko.lang.php
     * @author haneul <haneul0318@gmail.com>
     * @brief Korean language pack
     */

    $lang->referer = "点击来源";
    $lang->ranking = "访问次数";
?>
