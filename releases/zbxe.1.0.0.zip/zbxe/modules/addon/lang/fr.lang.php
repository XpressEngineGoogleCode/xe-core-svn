<?php
    /**
     * @file   modules/addon/lang/fr.lang.php
     * @author zero (zero@nzeo.com)  Traduit par Pierre Duvent(PierreDuvent@gamil.com)
     * @brief  Paquet de la Langue francaise
     **/

    $lang->addon = "Compagnon";

    $lang->addon_info = 'Le r�sum� de la Compagnon';
    $lang->addon_maker = 'L\'Auteur de la Compagnon';
    $lang->addon_history = 'L\'Histoire de la Compagnon';

    $lang->about_addon = 'La Compagnon contr�le les actions plut�t d\'imprimer des r�sultats de HTML.<br/>Seulement par touche � bascule des compagnons que vous voulez faire marcher ou arr�ter, vous pouvez appliquer les fonctions tr�s utiles pour administrer votre site web.';
?>


