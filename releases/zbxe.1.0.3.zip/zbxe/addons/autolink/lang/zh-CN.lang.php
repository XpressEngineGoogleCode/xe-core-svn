<?php
    /**
     * @file   addons/autolink/lang/ko.lang.php
     * @author zero (zero@zeroboard.com)
     * @brief  中文语言包
     **/
    $lang->open_cur_window = "本页面";
    $lang->open_new_window = "新窗口";
?>
