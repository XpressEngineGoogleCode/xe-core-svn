<?php
    /**
     * @file   addons/autolink/lang/es.lang.php
     * @author zero (zero@zeroboard.com)
     * @brief  한국어 언어팩 (기본적인 내용만 수록)
     **/
    $lang->open_cur_window = "ventana actual";
    $lang->open_new_window = "una nueva ventana";
?>
