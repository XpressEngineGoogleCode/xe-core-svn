<?php
    /**
     * @file   /modules/editor/components/emoticon/lang/ko.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  编辑器(editor) 模块 >  引用句 (quotation) 编辑器语言包
     **/
    $lang->code_type = '语言类型';
?>
