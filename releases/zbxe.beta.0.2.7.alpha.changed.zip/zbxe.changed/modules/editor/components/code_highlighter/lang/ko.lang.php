<?php
    /**
     * @file   /modules/editor/components/emoticon/lang/ko.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  위지윅에디터(editor) 모듈 >  인용구 (quotation) 컴포넌트의 언어팩
     **/
    $lang->code_type = '언어 종류';
?>
