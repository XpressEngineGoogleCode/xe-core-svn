<?php
    /**
     * @file   addons/mobile/lang/ko.lang.php
     * @author zero (zero@nzeo.com)
     * @brief  English Language Pack (Basic Contents only)
     **/

    $lang->cmd_go_upper = 'Upper';
    $lang->cmd_go_home = 'Go Home';
?>
