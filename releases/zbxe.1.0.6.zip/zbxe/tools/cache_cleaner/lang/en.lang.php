<?php
    $lang->cache_cleaner = 'Recreat Cache File';
?>
