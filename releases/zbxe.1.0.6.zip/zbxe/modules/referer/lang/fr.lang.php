<?php
    /**
     * @file module/referer/lang/fr.lang.php
     * @author haneul <haneul0318@gmail.com> Traduit par Pierre Duvent <PierreDuvent@gmail.com>
     * @brief Paquet du langage en français pour le Module de référeur
     */

    $lang->referer = "Référeur";
    $lang->ranking = "Rang";
?>
