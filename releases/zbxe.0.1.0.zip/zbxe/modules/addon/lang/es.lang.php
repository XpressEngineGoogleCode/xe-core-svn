<?php
    /**
     * @file   es.lang.php
     * @author zero (zero@nzeo.com)
     * @brief  Paquete lenguage de Español 
     **/

    $lang->addon = "Adiciónales";

    $lang->addon_info = 'Información de Adiciónales';
    $lang->addon_maker = 'Autor';
    $lang->addon_history = 'Historia de modificación ';

    $lang->about_addon = 'Adiciónales más coltrola acciónes que salida de HTML.<br />Solo encendir o apagar los adiciónales puede utilizar los funciónes útiles de manejar el sitio.';
?>
