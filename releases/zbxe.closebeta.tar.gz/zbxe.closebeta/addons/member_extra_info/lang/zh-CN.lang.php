<?php
    $lang->alert_new_message_arrived = '您有新消息。要确认吗？';
?>
