<?php
    /**
     * @file   modules/message/lang/jp.lang.php
     * @author zero <zero@nzeo.com> 翻訳：RisaPapa
     * @brief  日本語言語パッページ（基本的な内容のみ）
     **/

    $lang->message = 'エラー表示';
    $lang->about_skin = "メッセージを表示する際のスキンが指定できます。";
?>
