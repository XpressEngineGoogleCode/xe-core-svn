<?php
    /**
     * @file   modules/message/lang/en.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  English language pack (basic)
     **/

    $lang->message = 'Show error';
    $lang->about_skin = "You can select skins of error messages";
?>
