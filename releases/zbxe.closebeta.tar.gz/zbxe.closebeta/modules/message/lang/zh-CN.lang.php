<?php
    /**
     * @file   modules/message/lang/zh-CN.lang.php
     * @author zero <zero@nzeo.com>
     * @brief  简体中文语言包（只收录基本内容）
     **/

    $lang->message = '错误提示';
    $lang->about_skin = "提示信息时，可以指定皮肤。";
?>