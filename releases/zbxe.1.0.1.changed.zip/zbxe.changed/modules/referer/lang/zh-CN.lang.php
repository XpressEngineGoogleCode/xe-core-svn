<?php
    /**
     * @file module/referer/lang/zh-CN.lang.php
     * @author haneul <haneul0318@gmail.com>
     * @brief Korean language pack
     */

    $lang->referer = "用户来源";
    $lang->ranking = "排名";
?>
