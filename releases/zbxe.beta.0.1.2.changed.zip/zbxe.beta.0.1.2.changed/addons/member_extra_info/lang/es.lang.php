<?php
    $lang->alert_new_message_arrived = 'Te ha llegado un nuevo mensaje. Deseas leer ahora?';
?>
