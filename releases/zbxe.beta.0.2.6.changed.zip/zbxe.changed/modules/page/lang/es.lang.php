<?php
    /**
     * @archivo   modules/page/lang/es.lang.php
     * @autor zero (zero@nzeo.com)
     * @sumario Paquete del idioma español para la página de módulo (básico)
     **/

    $lang->page = "Página";
    $lang->about_page = "Esto es un módulo de blog, lo cual usted puede crear una página completa.\nUsando los últimos u otros widgets, Usted puede crear una página dinámica. A través del componente del editor, también puede crear páginas de gran variedad.\nURL de conección es el mismo que de los otros módulos como mid=Nombre del módulo.\n Si selcciona como predefinido esta página será la página principal del sitio.";
    $lang->cmd_page_modify = "Modificar";
?>
