<?php
    $lang->alert_new_message_arrived = 'Ha llegado un nuevo mensaje. ��Desea leer ahora?';
?>
